create procedure countOfAllProductInStore(IN storeId int, OUT countOfProd int)
  BEGIN
	SELECT SUM(availabitily.count) 
    INTO countOfProd 
    FROM availabitily 
    WHERE  availabitily.idStore = storeId;
END;

