create view product_store as
  select
    `db_labs`.`product`.`title`       AS `PRODUCT NAME`,
    `db_labs`.`product`.`description` AS `DESCRIPTION`,
    `db_labs`.`store`.`title`         AS `STORE`,
    `db_labs`.`store`.`address`       AS `STORE ADDRESS`
  from `db_labs`.`product`
    join `db_labs`.`availabitily`
    join `db_labs`.`store`
  where ((`db_labs`.`product`.`idProd` = `db_labs`.`availabitily`.`idProd`) and
         (`db_labs`.`availabitily`.`idStore` = `db_labs`.`store`.`idStore`));

