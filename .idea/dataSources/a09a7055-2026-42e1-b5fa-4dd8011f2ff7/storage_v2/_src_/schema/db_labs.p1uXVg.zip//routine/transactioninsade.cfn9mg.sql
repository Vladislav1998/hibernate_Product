create procedure transactionInsade(IN id int)
  BEGIN
START TRANSACTION;
    SELECT @A:=SUM(count) FROM availabitily WHERE idStore = id;
    UPDATE store SET currentCountOfProduct=@A WHERE idStore = id;
    IF @error != 0 
    THEN
    ROLLBACK;
    ELSE
    COMMIT;
    END IF;
END;

