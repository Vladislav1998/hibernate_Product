create trigger countOnStore
  before INSERT
  on supply
  for each row
  BEGIN
	IF EXISTS (SELECT * FROM availabitily WHERE idProd = NEW.idProd and idStore = NEW.idStore) THEN
	UPDATE availabitily  SET count = count+NEW.count WHERE NEW.idProd = availabitily.idProd AND NEW.idStore = availabitily.idStore;
    ELSE INSERT INTO availabitily VALUES(NEW.idProd, new.idStore, new.count);
    END IF;
END;

